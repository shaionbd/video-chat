$(document).ready(function(){

	$('#add-user').on('submit', function(){
		$(this).submit();
	});

});